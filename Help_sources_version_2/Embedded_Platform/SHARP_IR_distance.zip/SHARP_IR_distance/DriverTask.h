#include <TaskManager.h>
#include <DistanceDriver.h>
#include <filter.h>

template<class T>
class CDriverTask: public CTask
{
    public:
        using FilterFunc=filter::lti::siso::CFilterFunction<T>;
        CDriverTask( uint32_t f_period
                    ,PinName f_pin
                    ,FilterFunc& f_filter
                    ,Serial& f_serial)
                    :CTask(f_period)
                    ,m_filter(f_filter)
                    ,m_distanceDriver(f_pin)
                    ,val_brut(0.0)
                    ,val_filtrat(0.0)
                    ,m_serial(f_serial)
        {
        }
    
    T getDistance(){
        return val_filtrat;
    }
    
    private:
        virtual void _run(){
            val_brut=m_distanceDriver.ReadDistance();
            val_filtrat=m_filter(val_brut);
            m_serial.printf("%.4f,%.4f\n", static_cast<float>(val_brut),static_cast<float>( val_filtrat));
        }

        FilterFunc&     m_filter;
        DistanceDriver  m_distanceDriver;
        T val_brut;
        T val_filtrat;
        Serial& m_serial;
};