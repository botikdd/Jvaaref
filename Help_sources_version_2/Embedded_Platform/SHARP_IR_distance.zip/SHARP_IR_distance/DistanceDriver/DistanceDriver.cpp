#include "DistanceDriver.h"


DistanceDriver::DistanceDriver(PinName _pin):
pin(_pin)
{
};

DistanceDriver::~DistanceDriver()
{
};

float DistanceDriver::ReadDistance()
{
    float current_value=pin.read();
    //matek-scalare
    float scaled_value=current_value;
    return scaled_value;
}